#!/usr/bin/python
import json
import requests
import sys
from urllib3.exceptions import NewConnectionError

token = '3141620ff299d6c616763fc3'
baseCur = 'GBP'

def getExchangeRates(url):
	try:
		response = requests.get(url)
		if response.status_code == 200:
			rawData = json.loads(response.content.decode('utf-8'))
			if(list(rawData.items())[0][1] == "success"):
				return rawData['rates'].items()
			else:
				raise Exception("Invalid Start Currency")
	
	except:
		raise Exception('Cannot reach server')

	
			

def convert(rates,convCur):
	for k, v in rates:
		if (k == convCur):
			return v
	raise Exception("Invalid Convert-To Currency")

### Main Code
try:
	baseCur = sys.argv[1]
	convCur = sys.argv[2]
	url='https://v3.exchangerate-api.com/bulk/'+token+'/'+baseCur


	rates = getExchangeRates(url)
	print (convert(rates,convCur))
###	

### Exception Handling


except IndexError:
	print('Please provide a Start Currency and a Convert-To Currency')
	
except Exception as error:
	print(error)
except:
	print('unknown error')
###
	

